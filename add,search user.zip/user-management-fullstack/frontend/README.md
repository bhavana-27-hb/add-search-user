# Frontend - Vite + React + TypeScript (Minimal)

Install:
- npm install

Run dev:
- npm run dev

The frontend expects the backend on http://localhost:8080
Endpoints used:
- POST /api/users/add
- POST /api/users/search
