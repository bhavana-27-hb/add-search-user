import React, { useState } from 'react';
import AddUser from './pages/AddUser';
import ListUsers from './pages/ListUsers';
import SearchUsers from './pages/SearchUsers';

export default function App() {
  const [page, setPage] = useState<'home'|'add'|'list'|'search'>('home');

  return (
    <div style={{fontFamily: 'Arial, sans-serif', padding: 24}}>
      <h1 style={{textAlign:'center', color:'#4b62ff'}}>User Management System</h1>
      {page === 'home' && (
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:20, maxWidth:1000, margin:'20px auto'}}>
          <div style={{padding:20, borderRadius:8, background:'#fff', boxShadow:'0 4px 12px rgba(0,0,0,0.05)'}}>
            <h3>Add User</h3>
            <p>Create new user accounts with validation and encrypted password</p>
            <button onClick={()=>setPage('add')} style={{background:'#3b82f6', color:'#fff', padding:10, border:0, borderRadius:6}}>Add New User</button>
          </div>
          <div style={{padding:20, borderRadius:8, background:'#fff', boxShadow:'0 4px 12px rgba(0,0,0,0.05)'}}>
            <h3>List Users</h3>
            <p>View all registered users in a table</p>
            <button onClick={()=>setPage('list')} style={{background:'#3b82f6', color:'#fff', padding:10, border:0, borderRadius:6}}>View All Users</button>
          </div>
          <div style={{padding:20, borderRadius:8, background:'#fff', boxShadow:'0 4px 12px rgba(0,0,0,0.05)'}}>
            <h3>Search Users</h3>
            <p>Find users by username, name or email</p>
            <button onClick={()=>setPage('search')} style={{background:'#3b82f6', color:'#fff', padding:10, border:0, borderRadius:6}}>Search Users</button>
          </div>
        </div>
      )}

      {page === 'add' && <div><button onClick={()=>setPage('home')}>← Back</button><AddUser /></div>}
      {page === 'list' && <div><button onClick={()=>setPage('home')}>← Back</button><ListUsers /></div>}
      {page === 'search' && <div><button onClick={()=>setPage('home')}>← Back</button><SearchUsers /></div>}
    </div>
  );
}
