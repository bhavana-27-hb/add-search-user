import React, { useState } from 'react';

export default function AddUser(){
  const [form, setForm] = useState({username:'', firstName:'', lastName:'', email:'', password:''});
  const [msg, setMsg] = useState('');

  const submit = async (e:any) => {
    e.preventDefault();
    // basic client validation
    if(!form.username || !form.firstName || !form.lastName || !form.password) {
      setMsg('Please fill required fields');
      return;
    }
    const res = await fetch('http://localhost:8080/api/users/add', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify(form)
    });
    const txt = await res.text();
    setMsg(txt);
  };

  return (
    <div style={{maxWidth:600, margin:'20px auto', background:'#fff', padding:20, borderRadius:8}}>
      <h2>Add User</h2>
      <form onSubmit={submit}>
        <div style={{marginBottom:8}}>
          <label>Username*</label><br/>
          <input value={form.username} onChange={e=>setForm({...form, username:e.target.value})}/>
        </div>
        <div style={{display:'flex', gap:8}}>
          <div style={{flex:1}}><label>First name*</label><br/><input value={form.firstName} onChange={e=>setForm({...form, firstName:e.target.value})}/></div>
          <div style={{flex:1}}><label>Last name*</label><br/><input value={form.lastName} onChange={e=>setForm({...form, lastName:e.target.value})}/></div>
        </div>
        <div style={{marginTop:8}}>
          <label>Email</label><br/>
          <input value={form.email} onChange={e=>setForm({...form, email:e.target.value})}/>
        </div>
        <div style={{marginTop:8}}>
          <label>Password*</label><br/>
          <input type="password" value={form.password} onChange={e=>setForm({...form, password:e.target.value})}/>
        </div>
        <div style={{marginTop:12}}>
          <button type="submit" style={{background:'#10b981', color:'#fff', padding:8, border:0, borderRadius:6}}>Create User</button>
        </div>
      </form>
      {msg && <pre style={{background:'#f3f4f6', padding:8, marginTop:12}}>{msg}</pre>}
    </div>
  );
}
