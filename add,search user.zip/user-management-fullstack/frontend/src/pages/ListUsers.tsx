import React, { useEffect, useState } from 'react';

export default function ListUsers(){
  const [users, setUsers] = useState<any[]>([]);
  useEffect(()=>{ fetchUsers(); }, []);
  const fetchUsers = async ()=> {
    const res = await fetch('http://localhost:8080/api/users/search', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({})
    });
    const data = await res.json();
    setUsers(data);
  };
  return (
    <div style={{maxWidth:900, margin:'20px auto', background:'#fff', padding:20, borderRadius:8}}>
      <h2>All Users</h2>
      <button onClick={fetchUsers}>Refresh</button>
      <table style={{width:'100%', marginTop:12, borderCollapse:'collapse'}}>
        <thead><tr><th>Id</th><th>Username</th><th>Name</th><th>Email</th></tr></thead>
        <tbody>
          {users.map((u:any)=>(<tr key={u.id}><td style={{borderTop:'1px solid #eee', padding:8}}>{u.id}</td><td style={{borderTop:'1px solid #eee', padding:8}}>{u.username}</td><td style={{borderTop:'1px solid #eee', padding:8}}>{u.firstName} {u.lastName}</td><td style={{borderTop:'1px solid #eee', padding:8}}>{u.email}</td></tr>))}
        </tbody>
      </table>
    </div>
  );
}
