import React, { useState } from 'react';
export default function SearchUsers(){
  const [criteria, setCriteria] = useState({username:'', firstName:'', lastName:'', email:''});
  const [results, setResults] = useState<any[]>([]);
  const search = async (e:any) => {
    e.preventDefault();
    const res = await fetch('http://localhost:8080/api/users/search', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(criteria)
    });
    const data = await res.json();
    setResults(data);
  };
  return (
    <div style={{maxWidth:700, margin:'20px auto', background:'#fff', padding:20, borderRadius:8}}>
      <h2>Search Users</h2>
      <form onSubmit={search}>
        <div><label>Username</label><br/><input value={criteria.username} onChange={e=>setCriteria({...criteria, username:e.target.value})}/></div>
        <div style={{display:'flex', gap:8}}><div style={{flex:1}}><label>First name</label><br/><input value={criteria.firstName} onChange={e=>setCriteria({...criteria, firstName:e.target.value})}/></div><div style={{flex:1}}><label>Last name</label><br/><input value={criteria.lastName} onChange={e=>setCriteria({...criteria, lastName:e.target.value})}/></div></div>
        <div style={{marginTop:8}}><label>Email</label><br/><input value={criteria.email} onChange={e=>setCriteria({...criteria, email:e.target.value})}/></div>
        <div style={{marginTop:12}}><button style={{background:'#3b82f6', color:'#fff', padding:8, border:0, borderRadius:6}}>Search</button></div>
      </form>
      <div style={{marginTop:12}}>
        <h3>Results</h3>
        <ul>{results.map((r:any)=>(<li key={r.id}>{r.username} — {r.firstName} {r.lastName} — {r.email}</li>))}</ul>
      </div>
    </div>
  );
}
