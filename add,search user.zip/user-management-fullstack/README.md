# User Management Fullstack (Minimal Example)

This archive contains a minimal fullstack example (backend + frontend) that implements:
- Add user API (Spring Boot) with password encryption (BCrypt) and unique username check.
- Search users API.
- React frontend (Vite + TypeScript) with Add, List, and Search pages.

Quick start (recommended for development):
1. Backend:
   - cd backend
   - mvn clean package
   - mvn spring-boot:run
   Backend runs on port 8080 (H2 in-memory DB by default).

2. Frontend:
   - cd frontend
   - npm install
   - npm run dev
   Frontend runs on port 5173 by default.

Notes:
- For production or real DB, configure PostgreSQL in backend/src/main/resources/application.properties
- This is a minimal template to get you started and match the UI/UX from your screenshots.
