package com.example.usermgmt.controller;

import com.example.usermgmt.dto.UserRequest;
import com.example.usermgmt.model.User;
import com.example.usermgmt.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
@Validated
public class UserController {

    @Autowired
    private UserRepository userRepository;

    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    @PostMapping("/add")
    public ResponseEntity<?> addUser(@Valid @RequestBody UserRequest req) {
        // Validate unique username
        Optional<User> existing = userRepository.findByUsername(req.username());
        if (existing.isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("{"status":"USERNAME_TAKEN"}");
        }
        User u = new User();
        u.setUsername(req.username());
        u.setFirstName(req.firstName());
        u.setLastName(req.lastName());
        u.setEmail(req.email());
        u.setPassword(encoder.encode(req.password()));
        userRepository.save(u);
        return ResponseEntity.ok("{"status":"SUCCESS","userId":"" + u.getId() + ""}");
    }

    @PostMapping("/search")
    public ResponseEntity<?> searchUsers(@RequestBody(required = false) SearchRequest s) {
        if (s == null) s = new SearchRequest("", "", "", "");
        List<User> results = userRepository.findByUsernameContainingIgnoreCaseOrFirstNameContainingIgnoreCaseOrLastNameContainingIgnoreCaseOrEmailContainingIgnoreCase(
                s.username(), s.firstName(), s.lastName(), s.email()
        );
        return ResponseEntity.ok(results.stream().map(u -> new UserResponse(u.getId(), u.getUsername(), u.getFirstName(), u.getLastName(), u.getEmail())).toArray());
    }

    // Simple DTOs
    public static record SearchRequest(String username, String firstName, String lastName, String email) {}
    public static record UserResponse(Long id, String username, String firstName, String lastName, String email) {}
}
