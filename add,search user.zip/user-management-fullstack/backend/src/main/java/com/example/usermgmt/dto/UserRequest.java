package com.example.usermgmt.dto;

public record UserRequest(String username, String firstName, String lastName, String email, String password) {}
