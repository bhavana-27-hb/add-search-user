# Backend - Spring Boot (Minimal)

This is a minimal Spring Boot backend for the User Management System.

Run with:
- Java 17 and Maven installed
- `mvn clean package` then `mvn spring-boot:run` in the backend directory

API Endpoints:
- POST /api/users/add
  - Body: { "username","firstName","lastName","email","password" }
  - Returns: { "status":"SUCCESS", "userId":"<id>" } or {"status":"USERNAME_TAKEN"}
- POST /api/users/search
  - Body: { "username","firstName","lastName","email" } (all optional)
  - Returns: JSON array of users matching criteria

Default uses H2 in-memory DB for easy startup. Switch to PostgreSQL by setting datasource in application.properties.
